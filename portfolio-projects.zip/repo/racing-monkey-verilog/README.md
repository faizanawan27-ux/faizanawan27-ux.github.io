# Racing Monkey (Verilog)

Digital Logic Design Lab project — UET Peshawar.

An endless-runner style game implemented in **Verilog**: a monkey character
dodges incoming obstacles, built as digital logic (state machine / collision
detection, score and speed control).

> **Status: source not yet added.** This project's `.v` source files and
> testbench weren't part of the uploaded materials — add them here (e.g.
> `racing_monkey.v`, `racing_monkey_tb.v`) whenever you have them at hand,
> or send them over and I'll drop them in and update this README with the
> real module breakdown, target board, and how to simulate/synthesize it.

## What's here
- This README as a placeholder project page.

## To add
- [ ] Verilog source
- [ ] Testbench
- [ ] Target platform (FPGA board / simulation only)
- [ ] Block diagram / FSM diagram
- [ ] Simulation waveform or demo screenshots/video
