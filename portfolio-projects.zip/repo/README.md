# Faizan Awan — Project Portfolio

Source code and reports for my university projects (UET Peshawar, Computer
Systems Engineering), plus the source for my portfolio site.

## 🌐 Live site
`portfolio-site/` — deploy with GitHub Pages (see below) or open
`portfolio-site/index.html` directly.

## 📁 Projects

| Project | Area | Language/Stack |
|---|---|---|
| [metro-graph](metro-graph) | Data Structures & Algorithms | C++ |
| [smart-night-lamp-overheat-alarm](smart-night-lamp-overheat-alarm) | Embedded Systems | Bare-metal C (AVR) |
| [collaborative-text-editor](collaborative-text-editor) | Operating Systems | C (sockets, pthreads) |
| [hotel-booking-system](hotel-booking-system) | Database Systems | MySQL, Laravel/PHP |
| [fpga-temperature-monitor](fpga-temperature-monitor) | Digital System Design | Verilog (proposal stage) |
| [fourier-series-analysis](fourier-series-analysis) | Signals & Systems | MATLAB |
| [mobile-chatbot](mobile-chatbot) | AI / OOP | Python, TensorFlow |
| [racing-monkey-verilog](racing-monkey-verilog) | Digital Logic Design | Verilog (source pending) |
| [smart-security-alarm-system](smart-security-alarm-system) | Embedded Systems | Arduino/AVR (source pending) |

Each project folder has its own `README.md` with setup/run instructions.

## 🚀 Deploying the portfolio site to GitHub Pages

1. Create a new **public** repository on GitHub (e.g. `portfolio-projects`).
2. Push this folder's contents to it (see commands below).
3. On GitHub: **Settings → Pages → Source** → select the `main` branch and
   the `/portfolio-site` folder → **Save**.
4. GitHub gives you a public URL like
   `https://YOUR-USERNAME.github.io/portfolio-projects/` within a minute or two.
5. Open `portfolio-site/index.html` and replace every
   `YOUR-USERNAME` in the "View Code" links with your actual GitHub
   username, then commit again.

```bash
git init
git add .
git commit -m "Initial commit: portfolio + project source"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/portfolio-projects.git
git push -u origin main
```

If you'd rather have the site at the repo root (shorter URL path), move the
contents of `portfolio-site/` to the repo root and set Pages' source folder
to `/ (root)` instead.
