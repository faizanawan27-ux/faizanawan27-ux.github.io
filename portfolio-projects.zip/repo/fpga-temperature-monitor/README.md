# FPGA Real-Time Temperature Monitor

Digital System Design Lab project — UET Peshawar, Spring 2025.

> **Status: proposal / design stage.** The team's submitted deliverable for
> this project was the design proposal below; the Verilog implementation
> was not included in the uploaded materials, so no source is published
> here yet.

## Project title
Real-Time Temperature Monitoring System Using FPGA

## Overview
A real-time temperature monitoring system on a **Spartan-6 FPGA**,
interfacing with an analog **LM35** temperature sensor via an **MCP3008**
ADC, with a live readout and threshold-based alerts.

## Objectives
- Interface the LM35 sensor with the Spartan-6 FPGA through an ADC module.
- Digitally process sensor data to obtain precise temperature values.
- Display real-time temperature readings on an LCD or seven-segment display.
- Implement alert mechanisms (LED/buzzer) for threshold-exceeding
  temperatures.

## Working principle
The LM35 outputs an analog voltage proportional to temperature. The
MCP3008 ADC converts this to a digital value and sends it to the FPGA over
**SPI**. Verilog HDL logic on the FPGA converts the raw ADC reading into a
temperature value, drives the display, and triggers an LED/buzzer alert if
a preset threshold is exceeded.

## Planned methodology
1. **Sensor integration** — LM35 → MCP3008 (SPI) → FPGA.
2. **FPGA data processing** — Verilog logic to read ADC data and convert to
   °C, continuously.
3. **Display output** — drive an LCD or seven-segment display.
4. **Alert system** — threshold-based LED/buzzer logic.

## Team
Anees Ur Rehman, Faizan, Waqas Atta, Zeeshan Ahmad — Section B.
